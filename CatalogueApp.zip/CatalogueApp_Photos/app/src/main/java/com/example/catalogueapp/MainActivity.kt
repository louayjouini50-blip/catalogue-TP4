package com.example.catalogueapp

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

data class Produit(val nom: String, val prix: String, val description: String)
data class SousCategorie(val nom: String, val imageRes: Int, val produits: List<Produit>)
data class Categorie(val nom: String, val imageRes: Int, val sousCategories: List<SousCategorie>)

class MainActivity : AppCompatActivity() {
    private lateinit var titre: TextView
    private lateinit var sousTitre: TextView
    private lateinit var listView: ListView
    private lateinit var boutonRetour: Button
    private var categorieChoisie: Categorie? = null
    private var sousCategorieChoisie: SousCategorie? = null

    private val catalogue = listOf(
        Categorie("Téléphones", R.drawable.cat_telephones, listOf(
            SousCategorie("Smartphones", R.drawable.sub_smartphones, listOf(
                Produit("Samsung Galaxy A55", "1 399 DT", "Smartphone Samsung polyvalent."),
                Produit("iPhone 15", "3 299 DT", "Smartphone Apple."),
                Produit("Xiaomi Redmi Note 13", "799 DT", "Smartphone Xiaomi.")
            )),
            SousCategorie("Téléphones simples", R.drawable.sub_telephones_simples, listOf(
                Produit("Nokia 105", "99 DT", "Téléphone simple avec fonctions essentielles."),
                Produit("Nokia 110", "129 DT", "Téléphone compact.")
            ))
        )),
        Categorie("Informatique", R.drawable.cat_informatique, listOf(
            SousCategorie("Ordinateurs portables", R.drawable.sub_laptops, listOf(
                Produit("HP Pavilion", "2 199 DT", "Ordinateur portable HP."),
                Produit("Lenovo IdeaPad", "1 899 DT", "Ordinateur portable Lenovo."),
                Produit("ASUS VivoBook", "2 049 DT", "Ordinateur portable ASUS.")
            )),
            SousCategorie("Accessoires PC", R.drawable.sub_accessoires_pc, listOf(
                Produit("Souris sans fil", "55 DT", "Souris sans fil compacte."),
                Produit("Clavier USB", "45 DT", "Clavier filaire USB."),
                Produit("Support ordinateur", "39 DT", "Support de bureau.")
            ))
        )),
        Categorie("Audio", R.drawable.cat_audio, listOf(
            SousCategorie("Casques", R.drawable.sub_casques, listOf(
                Produit("Casque Bluetooth", "120 DT", "Casque sans fil."),
                Produit("Casque gaming", "175 DT", "Casque pour jeux vidéo.")
            )),
            SousCategorie("Écouteurs", R.drawable.sub_ecouteurs, listOf(
                Produit("Écouteurs sans fil", "95 DT", "Écouteurs Bluetooth."),
                Produit("Écouteurs filaires", "25 DT", "Écouteurs avec câble.")
            ))
        )),
        Categorie("Montres", R.drawable.cat_montres, listOf(
            SousCategorie("Montres connectées", R.drawable.sub_montres_connectees, listOf(
                Produit("Samsung Galaxy Watch", "799 DT", "Montre connectée Samsung."),
                Produit("Xiaomi Smart Band", "159 DT", "Bracelet connecté.")
            )),
            SousCategorie("Montres classiques", R.drawable.sub_montres_classiques, listOf(
                Produit("Montre classique", "180 DT", "Montre quotidienne.")
            ))
        )),
        Categorie("Accessoires", R.drawable.cat_accessoires, listOf(
            SousCategorie("Chargeurs et câbles", R.drawable.sub_chargeurs, listOf(
                Produit("Chargeur USB-C", "45 DT", "Chargeur USB-C."),
                Produit("Câble USB-C", "15 DT", "Câble de recharge."),
                Produit("Power bank", "75 DT", "Batterie externe.")
            )),
            SousCategorie("Protection", R.drawable.sub_protection, listOf(
                Produit("Coque téléphone", "25 DT", "Coque de protection."),
                Produit("Verre de protection", "12 DT", "Protection d'écran.")
            ))
        ))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        titre = findViewById(R.id.textTitle)
        sousTitre = findViewById(R.id.textSubtitle)
        listView = findViewById(R.id.listViewCatalogue)
        boutonRetour = findViewById(R.id.buttonRetour)
        boutonRetour.setOnClickListener { retour() }
        afficherCategories()
    }

    private fun afficherCategories() {
        categorieChoisie = null
        sousCategorieChoisie = null
        boutonRetour.visibility = View.GONE
        titre.text = "MiniShop Catalogue"
        sousTitre.text = "Choisissez une catégorie"
        val adapter = object : ArrayAdapter<Categorie>(this, R.layout.row_categorie, R.id.textNomCategorie, catalogue) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = convertView ?: layoutInflater.inflate(R.layout.row_categorie, parent, false)
                val categorie = getItem(position)!!
                row.findViewById<ImageView>(R.id.imageCategorie).setImageResource(categorie.imageRes)
                row.findViewById<TextView>(R.id.textNomCategorie).text = categorie.nom
                return row
            }
        }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            categorieChoisie = catalogue[position]
            afficherSousCategories()
        }
    }

    private fun afficherSousCategories() {
        val categorie = categorieChoisie ?: return
        sousCategorieChoisie = null
        boutonRetour.visibility = View.VISIBLE
        titre.text = categorie.nom
        sousTitre.text = "Choisissez une sous-catégorie"
        val adapter = object : ArrayAdapter<SousCategorie>(
            this, R.layout.row_categorie, R.id.textNomCategorie, categorie.sousCategories
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = convertView ?: layoutInflater.inflate(R.layout.row_categorie, parent, false)
                val sousCategorie = getItem(position)!!
                row.findViewById<ImageView>(R.id.imageCategorie).setImageResource(sousCategorie.imageRes)
                row.findViewById<TextView>(R.id.textNomCategorie).text = sousCategorie.nom
                return row
            }
        }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            sousCategorieChoisie = categorie.sousCategories[position]
            afficherProduits()
        }
    }

    private fun afficherProduits() {
        val sousCategorie = sousCategorieChoisie ?: return
        boutonRetour.visibility = View.VISIBLE
        titre.text = sousCategorie.nom
        sousTitre.text = "${sousCategorie.produits.size} produits disponibles · Touchez un produit"
        val adapter = object : ArrayAdapter<Produit>(this, android.R.layout.simple_list_item_2,
            android.R.id.text1, sousCategorie.produits) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                val produit = getItem(position)!!
                row.findViewById<TextView>(android.R.id.text1).text = produit.nom
                row.findViewById<TextView>(android.R.id.text2).text = produit.prix
                return row
            }
        }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val p = sousCategorie.produits[position]
            Toast.makeText(this, "${p.nom} · ${p.prix}\n${p.description}", Toast.LENGTH_LONG).show()
        }
    }

    private fun retour() {
        when {
            sousCategorieChoisie != null -> {
                sousCategorieChoisie = null
                afficherSousCategories()
            }
            categorieChoisie != null -> afficherCategories()
            else -> afficherCategories()
        }
    }
}
