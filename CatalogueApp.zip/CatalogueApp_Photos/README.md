# MiniShop Catalogue — catégories illustrées

Accueil avec une illustration devant chaque catégorie, puis navigation catégorie → sous-catégorie → produits.
Les illustrations sont des vecteurs intégrés au projet et fonctionnent hors ligne.

1. Décompresser le ZIP.
2. Ouvrir le dossier dans Android Studio.
3. Attendre Gradle Sync puis cliquer Run.
4. Les prix et produits sont des exemples modifiables dans MainActivity.kt.
